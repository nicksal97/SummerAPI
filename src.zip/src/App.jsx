﻿import { Routes, Route } from 'react-router-dom';
import LandingPage from './LandingPage';
import MapboxApp from './MapboxApp';
import Header from './Header';
import UploadModelPage from './UploadModelPage';
import AiModelPage from './AiModelPage';
import './App.css';
import { useLocation } from 'react-router-dom';

const App = () => {
  const location = useLocation();
  return (
      <div className="App">
        { 
          (location?.pathname !== '/'
            ) &&  
          <Header
            isNotificationOpen={false} 
            progress={0}
            converted={false}
            setIsNotificationOpen={() => {}}
            showLoader={false}
          />
        }
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/mapbox" element={<MapboxApp />} />
          <Route path="/model-upload" element={<UploadModelPage />} />
          <Route path="/ai-upload" element={<AiModelPage />} />
        </Routes>
      </div>
  );
};

export default App;
