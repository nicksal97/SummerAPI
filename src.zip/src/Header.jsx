﻿// src/Header.jsx
import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import logoPng from "./logo-1.png";

const FALLBACK_LOGO = "/logo192.png";

export default function Header({ onMenuClick }) {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [broken, setBroken] = useState(false);

  const go = (path) => () => navigate(path);
  const isActive = (path) =>
    pathname === path ? "bg-white/25" : "hover:bg-white/20";

  return (
    <header className="sticky top-0 z-40 bg-blue-600 text-white">
      <div className="mx-auto max-w-screen-2xl h-14 px-3 sm:px-5 flex items-center gap-3">

        {/* Burger button */}
        <button
          type="button"
          onClick={onMenuClick}
          className="mr-1 p-2 rounded-lg hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/30"
          aria-label="Open navigation"
          title="Open navigation"
        >
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
            <path d="M3 6h18v2H3zm0 5h18v2H3zm0 5h18v2H3z" />
          </svg>
        </button>

        {/* Brand */}
        <button
          type="button"
          onClick={go("/")}
          className="flex items-center gap-2 bg-white/15 hover:bg-white/25 px-2.5 py-1.5 rounded-lg transition"
          title="Home"
        >
          <div className="h-7 w-7 overflow-hidden rounded-md bg-white/20 flex items-center justify-center">
            {!broken ? (
              <img
                src={logoPng}
                alt="must analytics"
                className="h-7 w-7 object-contain select-none"
                draggable="false"
                onError={(e) => {
                  e.currentTarget.src = FALLBACK_LOGO;
                  setBroken(true);
                }}
              />
            ) : (
              <img
                src={FALLBACK_LOGO}
                alt="must analytics"
                className="h-7 w-7 object-contain select-none"
                draggable="false"
              />
            )}
          </div>
          <span className="text-lg font-bold whitespace-nowrap">must analytics</span>
        </button>

        <div className="flex-1" />

        {/* Right actions (keep) */}
        <div className="flex items-center gap-2">
          <button onClick={go("/upload")} className={`px-2.5 py-1.5 rounded-lg transition ${isActive("/upload")}`}>Upload Model</button>
          <button onClick={go("/models")} className={`px-2.5 py-1.5 rounded-lg transition ${isActive("/models")}`}>AI Model</button>
          <button className="bg-white/15 hover:bg-white/25 px-2.5 py-1.5 rounded-lg transition" title="Notifications" aria-label="Notifications">🔔</button>
          <button onClick={go("/account")} className="bg-white/15 hover:bg-white/25 px-2.5 py-1.5 rounded-lg transition" title="Account" aria-label="Account">👤</button>
        </div>
      </div>
    </header>
  );
}
