﻿import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'; // Add your custom styles here
import Loader from './components/Loader';
import { BASE_URL } from './utils/constants';


const AiModelPage = () => {
  const [selectedModel, setSelectedModel] = useState('winter');
  const [modelNames, setModelNames] = useState([]);
  const [selectedModelName, setSelectedModelName] = useState('');
  const [tifFile, setTifFile] = useState(null);
  const [zipFile, setZipFile] = useState(null);
  const [originalImages, setOriginalImages] = useState([]);
  const [processedImages, setProcessedImages] = useState([]);
  const [geojsonPath, setGeojsonPath] = useState('');
  const [zipPath, setZipPath] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const handleTifChange = (e) => {
    setTifFile(e.target.files[0]);
    setZipFile(null); // Reset zip file when tif is selected
  };

  const handleZipChange = (e) => {
    setZipFile(e.target.files[0]);
    setTifFile(null); // Reset tif file when zip is selected
  };

  useEffect(() => {
    const id = sessionStorage.getItem('mapbox_unique');
    if(!id) {
      navigate('/');
      setIsLoading(false)
    } else {
      setIsLoading(false)
    }
  }, [])

  // Fetch model names when the selected model changes
  useEffect(() => {
      fetchModelNames(selectedModel);
  }, [selectedModel]);

  // Function to fetch model names
  const fetchModelNames = async (model) => {
    try {
      const response = await axios.get(`${BASE_URL}/model-upload1/?model=${model}`);
      setModelNames(response.data.model_path.filter((path) => path !== '.DS_Store'));
    } catch (error) {
      console.error('Error fetching model names:', error);
    }
  };

  // Handle form submission
  const handleSubmit = async () => {
    if (!tifFile && !zipFile) {
      alert('Please select either a .zip file or a .tif file.');
      return;
    }

    const formData = new FormData();
    if (zipFile) formData.append('file', zipFile);
    if (tifFile) formData.append('tif_file', tifFile);
    formData.append('model', selectedModel);
    formData.append('model_name', selectedModelName);

    setIsLoading(true);

    try {
      const response = await axios.post(`${BASE_URL}/`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      const { geojson_path, input_image_list, output_image_list, zip_path } = response.data;

      setOriginalImages(input_image_list);
      setProcessedImages(output_image_list);
      setGeojsonPath(geojson_path);
      setZipPath(zip_path);
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('An error occurred while processing the files.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
  <>
    {
      isLoading ? 
      <Loader /> :
      <div>
        {/* Overlay for loading */}
        {isLoading && (
          <div className="overlay">
            <div className="loader"></div>
          </div>
        )}

        {/* Top navigation bar */}
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <a className="navbar-brand btn btn-primary text-white mr-2" href="/mapbox">
            Home
          </a>
          <a className="navbar-brand btn btn-success text-white mr-2" href="/model-upload">
            Upload Model
          </a>
          <div className="ml-auto">
            <a href="/logout" className="btn btn-outline-danger">
              Logout
            </a>
          </div>
        </nav>

        {/* Main container */}
        <div className="container">
          <form className='flex flex-col gap-4 max-w-[500px] mx-auto mb-8'>
            <h1 className="text-center">TREE PROJECT</h1>
            <div className="form-group">
              <label htmlFor="model">Select Model Type:</label>
              <select
                className="form-control"
                id="model"
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value)}
              >
                <option value="winter">Winter</option>
                <option value="summer">Summer</option>
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="model_name">Select Model Name:</label>
              <select
                className="form-control"
                id="model_name"
                value={selectedModelName}
                onChange={(e) => setSelectedModelName(e.target.value)}
              >
                <option value="">Select a model</option>
                {modelNames.map((name, index) => (
                  <option key={index} value={name}>
                    {name}
                  </option>
                ))}
              </select>
            </div>
            {!zipFile && (
              <div className="form-group">
                <label htmlFor="tif_file">Select TIF File:</label>
                <input
                  type="file"
                  className="form-control"
                  id="tif_file"
                  onChange={handleTifChange}
                  accept=".tif"
                />
              </div>
            )}

            {!tifFile && (
              <div className="form-group">
                <label htmlFor="file">Select ZIP Folder:</label>
                <input
                  type="file"
                  className="form-control"
                  id="file"
                  onChange={handleZipChange}
                  accept=".zip"
                />
              </div>
            )}
            <button type="button" className="btn btn-primary" onClick={handleSubmit}>
              Submit
            </button>
          </form>
          <br />
          <div className="container" id="main_container">
            <div className="row">
              <div className="col">
                <h3>Original Images</h3>
                <div id="original-images" className="ScrollStyle">
                  {originalImages?.map((image, index) => (
                    <img key={index} src={`${BASE_URL}${image}`} alt="original" className="img-fluid mb-2" />
                  ))}
                </div>
                <a id="download-zip" href={`${BASE_URL}${zipPath}`} download="output.zip" className="btn btn-primary">
                  Zip-File-Download
                </a>
              </div>
              <div className="col">
                <h3>Processed Images</h3>
                <div id="processed-images" className="ScrollStyle">
                  {processedImages.map((image, index) => (
                    <img key={index} src={`${BASE_URL}${image}`} alt="processed" className="img-fluid mb-2" />
                  ))}
                </div>
                <a
                  id="download-geojson"
                  href={`${BASE_URL}${geojsonPath}`}
                  download="output.geojson"
                  className="btn btn-primary"
                >
                  GeoJSON-Download
                </a>
              </div>
            </div>
            <div id="model-name" className="text-center mt-3">
              Model Used: {selectedModel}
            </div>
          </div>
          <br />
        </div>
      </div>
     }
    </>
  );
};

export default AiModelPage;
