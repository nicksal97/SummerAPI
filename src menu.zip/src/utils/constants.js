﻿
// export const BASE_URL = 'http://192.168.50.214:8009'; 

export const BASE_URL = 'http://127.0.0.1:8000'; 


