// SidebarNavigation.jsx
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  HomeIcon, 
  ArrowUpTrayIcon, 
  CpuChipIcon, 
  Squares2X2Icon, 
  MagnifyingGlassIcon,
  XMarkIcon,
  Bars3Icon
} from '@heroicons/react/24/outline';

const SidebarNavigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { id: 'home', label: 'Home', icon: HomeIcon, path: '/mapbox' },
    { id: 'upload', label: 'Upload Model', icon: ArrowUpTrayIcon, path: '/model-upload' },
    { id: 'ai-model', label: 'AI Model', icon: CpuChipIcon, path: '/ai-upload' },
    { id: 'layers', label: 'Layers', icon: Squares2X2Icon, path: '/mapbox' },
    { id: 'explore', label: 'Explore', icon: MagnifyingGlassIcon, path: '/mapbox' },
  ];

  const handleNavigation = (path) => {
    navigate(path);
    setIsOpen(false);
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed top-4 left-4 z-50 p-2 rounded-md bg-blue-600 text-white md:hidden"
      >
        <Bars3Icon className="h-6 w-6" />
      </button>

      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
          onClick={() => setIsOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <div className={`
        fixed top-0 left-0 h-full w-64 bg-gray-900 text-white z-50 transform transition-transform duration-300
        ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 md:static md:z-auto
      `}>
        {/* Close button for mobile */}
        <button
          onClick={() => setIsOpen(false)}
          className="absolute top-4 right-4 p-1 rounded-md text-gray-400 hover:text-white md:hidden"
        >
          <XMarkIcon className="h-6 w-6" />
        </button>

        {/* Logo */}
        <div className="p-6 border-b border-gray-800">
          <h1 className="text-xl font-bold">Prodigal</h1>
          <p className="text-gray-400 text-sm">Invo.</p>
        </div>

        {/* Navigation */}
        <nav className="p-4">
          <ul className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => handleNavigation(item.path)}
                    className={`
                      w-full flex items-center px-4 py-3 rounded-lg text-left transition-colors
                      ${isActive(item.path) 
                        ? 'bg-blue-600 text-white' 
                        : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                      }
                    `}
                  >
                    <Icon className="h-5 w-5 mr-3" />
                    {item.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Additional sections can be added here */}
        <div className="p-4 border-t border-gray-800 mt-4">
          <p className="text-gray-400 text-sm mb-2">Settings & Help</p>
          <ul className="space-y-2">
            <li>
              <button className="w-full text-left px-4 py-2 text-gray-300 hover:text-white">
                Settings
              </button>
            </li>
            <li>
              <button className="w-full text-left px-4 py-2 text-gray-300 hover:text-white">
                Help & Support
              </button>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

export default SidebarNavigation;