import { useEffect, useRef, useState, useCallback } from 'react';
import mapboxgl from 'mapbox-gl';
import './App.css';
import ThemeSelector from './ThemeSwitcher';
import { useNavigate } from 'react-router-dom';
import Loader from './components/Loader';

mapboxgl.accessToken =
  'pk.eyJ1IjoibWlya2hhZ2FuIiwiYSI6ImNtMDQzYnBtNjAycmkyanNibXRvaTg3dDIifQ.PPYVLIlidbRLbaiaHiie2g';

const MapboxMap = ({ layers, zoomid, setZoom, Rasterzoomid, tiffLayers, setRasterzoomid }) => {
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);
  const navigate = useNavigate();
  const [mapLoaded, setMapLoaded] = useState(false);
  const [Loading, setLoading] = useState(true);

  // ---------------- Auth guard ----------------
  useEffect(() => {
    const id = sessionStorage.getItem('mapbox_unique');
    if (!id) {
      navigate('/');
      setLoading(false);
    } else {
      setLoading(false);
    }
  }, [navigate]);

  // ---------------- Projection helpers ----------------
  const epsg3857to4326 = ([xIn, yIn]) => {
    // Web Mercator meters -> lon/lat degrees
    let x = (xIn * 180) / 20037508.34;
    let y = (yIn * 180) / 20037508.34;
    y = (Math.atan(Math.exp((y * Math.PI) / 180)) * 360) / Math.PI - 90;
    return [x, y];
  };

  const isLikelyWebMercator = ([x, y]) => Math.abs(x) > 180 || Math.abs(y) > 90;
  // lat,lon mistake (x looks like latitude, y looks like longitude)
  const isLikelyLatLonPair = ([x, y]) => Math.abs(x) <= 90 && Math.abs(y) > 90 && Math.abs(y) <= 180;

  // Collect sample coordinate PAIRS from any geometry
  const samplePairs = (geometry, limit = 400) => {
    const pairs = [];
    const walk = (coords) => {
      if (!coords || pairs.length >= limit) return;
      if (Array.isArray(coords) && typeof coords[0] === 'number') {
        pairs.push(coords);
        return;
      }
      if (Array.isArray(coords)) coords.forEach(walk);
    };
    if (geometry) walk(geometry.coordinates);
    return pairs;
  };

  // Decide if a FeatureCollection needs swap (lat,lon->lon,lat) and/or 3857 conversion
  const detectHints = (fc) => {
    let total = 0;
    let latLonCount = 0;
    let mercCount = 0;
    fc?.features?.forEach((f) => {
      const s = samplePairs(f.geometry, 80);
      s.forEach((p) => {
        total += 1;
        if (isLikelyWebMercator(p)) mercCount += 1;
        else if (isLikelyLatLonPair(p)) latLonCount += 1;
      });
    });
    return {
      shouldSwap: total ? latLonCount / total > 0.6 : false,
      mostlyMerc: total ? mercCount / total > 0.6 : false,
    };
  };

  const normalizePair = ([x, y], hints) => {
    // Convert meters first if necessary
    if (isLikelyWebMercator([x, y])) {
      return epsg3857to4326([x, y]);
    }
    // Swap if file seems saved as lat,lon OR this pair looks like lat,lon
    if (hints?.shouldSwap || isLikelyLatLonPair([x, y])) {
      return [y, x];
    }
    return [x, y]; // already lon,lat degrees
  };

  const mapCoordsDeep = (coords, hints) => {
    if (!coords) return coords;
    if (Array.isArray(coords) && typeof coords[0] === 'number') {
      return normalizePair(coords, hints);
    }
    if (Array.isArray(coords)) return coords.map((c) => mapCoordsDeep(c, hints));
    return coords;
  };

  // Create a NEW FeatureCollection with normalized coordinates
  const normalizeGeoJSON = (fc) => {
    if (!fc?.features) return fc;
    const hints = detectHints(fc);
    return {
      ...fc,
      features: fc.features.map((feat) => ({
        ...feat,
        geometry: {
          ...feat.geometry,
          coordinates: mapCoordsDeep(feat.geometry?.coordinates, hints),
        },
      })),
    };
  };

  // ---------------- Map init ----------------
  const initializeMap = useCallback(() => {
    if (mapRef.current || !mapContainerRef.current) return;

    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [0, 0],
      zoom: 1,
      attributionControl: false,
    });

    mapRef.current = map;
    map.on('load', () => {
      setMapLoaded(true);
      setTimeout(() => map.resize(), 500);
    });

    return () => map.remove();
  }, []);

  useEffect(() => {
    const t = setTimeout(initializeMap, 200);
    return () => clearTimeout(t);
  }, [initializeMap]);

  // ---------------- Zoom to selected GeoJSON layer ----------------
  useEffect(() => {
    if (!mapLoaded || !zoomid) return;
    const map = mapRef.current;
    if (!map) return;

    const layer = layers.find((l) => l.id === zoomid);
    if (!layer?.data?.features?.length) {
      setZoom(null);
      return;
    }

    const data = normalizeGeoJSON(layer.data);
    const bounds = new mapboxgl.LngLatBounds();
    let hasAny = false;

    data.features.forEach((feature) => {
      const coords = samplePairs(feature.geometry, Number.POSITIVE_INFINITY);
      coords.forEach((c) => {
        bounds.extend(c);
        hasAny = true;
      });
    });

    if (hasAny && !bounds.isEmpty()) {
      // If it’s exactly a single point, make it tighter
      const single = data.features.length === 1 && data.features[0].geometry.type === 'Point';
      map.fitBounds(bounds, {
        padding: 50,
        maxZoom: single ? 13 : 15,
        duration: 300,
      });
    }

    setZoom(null);
  }, [zoomid, layers, mapLoaded, setZoom]);

  // ---------------- Update map (TIFF + GeoJSON) ----------------
  const updateMapLayers = useCallback(() => {
    if (!mapLoaded) return;
    const map = mapRef.current;
    if (!map) return;

    // --- Keep TIFF logic exactly like your old code ---
    const mapBounds = map.getBounds();

    tiffLayers.forEach((tiff) => {
      const { id, boundingBox, mapboxUrl } = tiff;
      if (!id || !boundingBox || !mapboxUrl) return;

      const sourceId = `raster-layer-${id}`;
      const circleLayerId = `circle-layer-${id}`;

      const layerBounds = [
        parseFloat(boundingBox.minx),
        parseFloat(boundingBox.miny),
        parseFloat(boundingBox.maxx),
        parseFloat(boundingBox.maxy),
      ];

      const isLayerInViewport =
        layerBounds[2] > mapBounds.getWest() &&
        layerBounds[0] < mapBounds.getEast() &&
        layerBounds[3] > mapBounds.getSouth() &&
        layerBounds[1] < mapBounds.getNorth();

      const updatedVisibility = isLayerInViewport ? 'visible' : 'none';

      if (!map.getSource(sourceId)) {
        map.addSource(sourceId, { type: 'raster,', tiles: [mapboxUrl], tileSize: 512 });
      }
      if (!map.getLayer(sourceId)) {
        map.addLayer({ id: sourceId, type: 'raster', source: sourceId, layout: { visibility: updatedVisibility } });
      } else {
        map.setLayoutProperty(sourceId, 'visibility', updatedVisibility);
      }

      if (!map.getLayer(circleLayerId)) {
        map.addLayer({
          id: circleLayerId,
          type: 'circle',
          source: {
            type: 'geojson',
            data: {
              type: 'FeatureCollection',
              features: [
                {
                  type: 'Feature',
                  geometry: {
                    type: 'Point',
                    coordinates: [(layerBounds[0] + layerBounds[2]) / 2, (layerBounds[1] + layerBounds[3]) / 2],
                  },
                },
              ],
            },
          },
          paint: { 'circle-radius': 6, 'circle-color': '#000000' },
          layout: { visibility: 'none' },
        });
      }

      map.on('zoom', () => {
        const z = map.getZoom();
        map.setLayoutProperty(circleLayerId, 'visibility', z < 8 ? 'visible' : 'none');
      });
    });

    // --- GeoJSON (normalized) ---
    layers.forEach((layer) => {
      if (!layer?.data) return;

      const base = `geojson-layer-${layer.id}`;
      const data = normalizeGeoJSON(layer.data);
      const visible = layer.visible ? 'visible' : 'none';

      const points = {
        type: 'FeatureCollection',
        features: data.features.filter((f) => f.geometry?.type === 'Point'),
      };
      const lines = {
        type: 'FeatureCollection',
        features: data.features.filter((f) => ['LineString', 'MultiLineString'].includes(f.geometry?.type)),
      };
      const polys = {
        type: 'FeatureCollection',
        features: data.features.filter((f) => ['Polygon', 'MultiPolygon'].includes(f.geometry?.type)),
      };

      const ensureSource = (id, fc) => {
        if (!map.getSource(id)) map.addSource(id, { type: 'geojson', data: fc });
        else map.getSource(id).setData(fc);
      };
      const ensureLayer = (id, type, src, paint) => {
        if (!map.getLayer(id)) {
          map.addLayer({ id, type, source: src, paint, layout: { visibility: visible } });
        } else {
          map.setLayoutProperty(id, 'visibility', visible);
          Object.entries(paint).forEach(([k, v]) => map.setPaintProperty(id, k, v));
        }
      };

      // Polys (fill + border)
      if (polys.features.length) {
        const fillId = `${base}-polygons`;
        const borderId = `${base}-border`;
        ensureSource(fillId, polys);
        ensureLayer(fillId, 'fill', fillId, { 'fill-color': '#22c55e', 'fill-opacity': 0.35 });
        ensureSource(borderId, polys);
        ensureLayer(borderId, 'line', borderId, { 'line-color': '#16a34a', 'line-width': 2 });

        const clickHandler = (e) => {
          const feature = e.features?.[0];
          if (!feature) return;
          const area = parseFloat(feature.properties?.area);
          const displayArea = isNaN(area) ? "Area's information not available" : `${area.toFixed(2)} m²`;
          new mapboxgl.Popup({ closeButton: true, closeOnClick: true, offset: [0, -10] })
            .setLngLat(e.lngLat)
            .setHTML(`<div style="text-align:center;"><strong>Area:</strong> ${displayArea}</div>`)
            .addTo(map);
        };
        map.off('click', fillId, clickHandler);
        map.on('click', fillId, clickHandler);
      }

      // Lines
      if (lines.features.length) {
        const id = `${base}-lines`;
        ensureSource(id, lines);
        ensureLayer(id, 'line', id, { 'line-color': '#2563eb', 'line-width': 2 });
      }

      // Points (add LAST so they sit on top and have crisp outline)
      if (points.features.length) {
        const id = `${base}-points`;
        ensureSource(id, points);
        ensureLayer(id, 'circle', id, {
          'circle-color': '#FF3B30',
          'circle-opacity': 0.95,
          'circle-stroke-color': '#FFFFFF',
          'circle-stroke-width': 1.5,
          'circle-radius': ['interpolate', ['linear'], ['zoom'], 2, 3, 6, 5, 10, 7, 14, 9],
        });
        try {
          map.moveLayer(id);
        } catch (_) {}
      }
    });
  }, [layers, tiffLayers, mapLoaded]);

  // keep TIFF visibility in sync with pan/zoom
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    map.on('moveend', updateMapLayers);
    map.on('zoomend', updateMapLayers);
    return () => {
      map.off('moveend', updateMapLayers);
      map.off('zoomend', updateMapLayers);
    };
  }, [updateMapLayers]);

  // Zoom to TIFF layer when Rasterzoomid changes
  useEffect(() => {
    if (!Rasterzoomid || !mapLoaded) return;
    const map = mapRef.current;
    const selected = tiffLayers.find((t) => t.id === Rasterzoomid);
    if (selected?.boundingBox) {
      const { minx, miny, maxx, maxy } = selected.boundingBox;
      map.fitBounds(
        [
          [parseFloat(minx), parseFloat(miny)],
        [parseFloat(maxx), parseFloat(maxy)],
        ],
        { padding: { top: 10, bottom: 10, left: 10, right: 10 }, maxZoom: 15, duration: 1000 }
      );
      setRasterzoomid(null);
    }
  }, [Rasterzoomid, tiffLayers, mapLoaded, setRasterzoomid]);

  // Theme switcher – repaint after style reload
  const handleThemeChange = (newTheme) => {
    const map = mapRef.current;
    if (!map) return;
    map.setStyle(`mapbox://styles/mapbox/${newTheme}`);
    map.once('styledata', () => updateMapLayers());
  };

  // Initial paint + whenever data changes
  useEffect(() => {
    updateMapLayers();
  }, [updateMapLayers]);

  return (
    <>
      {Loading ? (
        <Loader />
      ) : (
        <div className="relative">
          <div ref={mapContainerRef} className="map-container" />
          <ThemeSelector onThemeChange={handleThemeChange} />
        </div>
      )}
    </>
  );
};

export default MapboxMap;