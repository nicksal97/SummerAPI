﻿// Mapbox.jsx
import { useEffect, useRef, useState, useCallback } from 'react';
import mapboxgl from 'mapbox-gl';
import './App.css';
import ThemeSelector from './ThemeSwitcher';
import { useNavigate } from 'react-router-dom';
import Loader from './components/Loader';

mapboxgl.accessToken = 'pk.eyJ1IjoibWlya2hhZ2FuIiwiYSI6ImNtMDQzYnBtNjAycmkyanNibXRvaTg3dDIifQ.PPYVLIlidbRLbaiaHiie2g';

const MapboxMap = ({ layers, zoomid, setZoom, Rasterzoomid, tiffLayers, setRasterzoomid }) => {
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);
  const navigate = useNavigate();
  const [mapLoaded, setMapLoaded] = useState(false);
  const [Loading, setLoading] = useState(true);

  useEffect(() => {
    const id = sessionStorage.getItem('mapbox_unique');
    if (!id) {
      navigate('/');
      setLoading(false);
    } else {
      setLoading(false);
    }
  }, [navigate]);

  const epsg3857toEpsg4326 = (pos) => {
    let [x, y] = pos;
    x = (x * 180) / 20037508.34;
    y = (y * 180) / 20037508.34;
    y = (Math.atan(Math.exp(y * (Math.PI / 180))) * 360) / Math.PI - 90;
    return [x, y];
  };

  const returnEPSG4326 = (coordinates) => {
    if (Math.abs(coordinates[0]) > 180 || Math.abs(coordinates[1]) > 90) {
      return epsg3857toEpsg4326(coordinates);
    }
    return coordinates;
  };

  const transformCoords = (coords) => {
    if (typeof coords[0] === 'number') {
      return returnEPSG4326(coords);
    } else if (Array.isArray(coords[0])) {
      return coords.map((coord) => returnEPSG4326(coord));
    }
    return coords;
  };

  const convertGeometry = (geometry) => {
    const geomType = geometry.type;
    if (geomType === 'Point') {
      geometry.coordinates = transformCoords(geometry.coordinates);
    } else if (geomType === 'LineString' || geomType === 'MultiPoint') {
      geometry.coordinates = transformCoords(geometry.coordinates);
    } else if (geomType === 'Polygon' || geomType === 'MultiLineString') {
      geometry.coordinates = geometry.coordinates.map((ring) => transformCoords(ring));
    } else if (geomType === 'MultiPolygon') {
      geometry.coordinates = geometry.coordinates.map((polygon) =>
        polygon.map((ring) => transformCoords(ring))
      );
    }
    return geometry;
  };

  const convertGeoJSON = (geojsonData) => {
    geojsonData?.features?.forEach((feature) => {
      feature.geometry = convertGeometry(feature.geometry);
    });
    return geojsonData;
  };

  const initializeMap = useCallback(() => {
    if (mapRef.current || !mapContainerRef.current) return;

    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [0, 0],
      zoom: 1,
      attributionControl: false,
    });

    mapRef.current = map;

    map.on('load', () => {
      setMapLoaded(true);
      setTimeout(() => map.resize(), 500);
    });

    return () => map.remove();
  }, []);

  useEffect(() => {
    const t = setTimeout(() => initializeMap(), 200);
    return () => clearTimeout(t);
  }, [initializeMap]);

  // Zoom to a GeoJSON layer by id
  useEffect(() => {
    if (!mapLoaded || !zoomid) return;
    const map = mapRef.current;
    if (!map) return;

    const selectedLayer = layers.find((layer) => layer.id === zoomid);
    if (selectedLayer) {
      const bounds = new mapboxgl.LngLatBounds();

      selectedLayer?.data?.features?.forEach((feature) => {
        const geometryType = feature.geometry.type;

        if (geometryType === 'Point') {
          bounds.extend(feature.geometry.coordinates);
        } else if (geometryType === 'LineString' || geometryType === 'MultiLineString') {
          feature.geometry.coordinates.forEach((coord) => bounds.extend(coord));
        } else if (geometryType === 'Polygon' || geometryType === 'MultiPolygon') {
          const coordinates =
            geometryType === 'Polygon'
              ? feature.geometry.coordinates[0]
              : feature.geometry.coordinates.flat(2);
          coordinates.forEach((coord) => bounds.extend(coord));
        }
        setZoom(null);
      });

      if (!bounds.isEmpty()) {
        map.fitBounds(bounds, { padding: 50, maxZoom: 15, duration: 1 });
      }
    }
  }, [zoomid, layers, mapLoaded, setZoom]);

  const updateMapLayers = useCallback(() => {
    if (!mapLoaded) return;
    const map = mapRef.current;
    if (!map) return;

    // ====== Raster TIFF layers (WMS tiles) visibility by viewport ======
    tiffLayers.forEach((tiff) => {
      const { id, boundingBox, mapboxUrl } = tiff;
      const sourceId = `raster-layer-${id}`;
      const circleLayerId = `circle-layer-${id}`;

      const layerBounds = [
        parseFloat(boundingBox.minx),
        parseFloat(boundingBox.miny),
        parseFloat(boundingBox.maxx),
        parseFloat(boundingBox.maxy),
      ];

      const mapBounds = map.getBounds();
      const isLayerInViewport =
        layerBounds[2] > mapBounds.getWest() &&
        layerBounds[0] < mapBounds.getEast() &&
        layerBounds[3] > mapBounds.getSouth() &&
        layerBounds[1] < mapBounds.getNorth();

      const updatedVisibility = isLayerInViewport ? 'visible' : 'none';

      if (!map.getSource(sourceId)) {
        map.addSource(sourceId, {
          type: 'raster',
          tiles: [mapboxUrl],
          tileSize: 512,
        });
      }

      if (!map.getLayer(sourceId)) {
        map.addLayer({
          id: sourceId,
          type: 'raster',
          source: sourceId,
          layout: { visibility: updatedVisibility },
        });
      } else {
        map.setLayoutProperty(sourceId, 'visibility', updatedVisibility);
      }

      if (!map.getLayer(circleLayerId)) {
        map.addLayer({
          id: circleLayerId,
          type: 'circle',
          source: {
            type: 'geojson',
            data: {
              type: 'FeatureCollection',
              features: [
                {
                  type: 'Feature',
                  geometry: {
                    type: 'Point',
                    coordinates: [
                      (layerBounds[0] + layerBounds[2]) / 2,
                      (layerBounds[1] + layerBounds[3]) / 2,
                    ],
                  },
                },
              ],
            },
          },
          paint: {
            'circle-radius': 6,
            'circle-color': '#000000',
          },
          layout: { visibility: 'none' },
        });
      }

      map.on('zoom', () => {
        const zoom = map.getZoom();
        map.setLayoutProperty(circleLayerId, 'visibility', zoom < 8 ? 'visible' : 'none');
      });
    });

    // ====== GeoJSON layers ======
    const layersToUpdate = { points: [], lines: [], polygons: [] };

    const getOrCreateSource = (sourceId, data) => {
      if (!map.getSource(sourceId)) {
        map.addSource(sourceId, { type: 'geojson', data });
      } else {
        map.getSource(sourceId).setData(data);
      }
    };

    const getOrCreateLayer = (layerId, layerType, sourceId, paintOptions, visibility) => {
      if (!map.getLayer(layerId)) {
        map.addLayer({
          id: layerId,
          type: layerType,
          source: sourceId,
          paint: paintOptions,
          layout: { visibility: visibility ? 'visible' : 'none' },
        });
      } else {
        map.setLayoutProperty(layerId, 'visibility', visibility ? 'visible' : 'none');
        Object.entries(paintOptions).forEach(([key, value]) => {
          map.setPaintProperty(layerId, key, value);
        });
      }
    };

    layers.forEach((layer) => {
      const layerIdBase = `geojson-layer-${layer.id}`;
      const convertedGeoJSON = convertGeoJSON(layer.data);

      const pointFeatures = {
        type: 'FeatureCollection',
        features: convertedGeoJSON?.features?.filter((f) => f.geometry.type === 'Point'),
      };

      const lineStringFeatures = {
        type: 'FeatureCollection',
        features: convertedGeoJSON?.features?.filter(
          (f) => f.geometry.type === 'LineString' || f.geometry.type === 'MultiLineString'
        ),
      };

      const polygonFeatures = {
        type: 'FeatureCollection',
        features: convertedGeoJSON?.features?.filter(
          (f) => f.geometry.type === 'Polygon' || f.geometry.type === 'MultiPolygon'
        ),
      };

      const visibility = layer.visible;

      if (pointFeatures?.features?.length > 0) {
        const pointLayerId = `${layerIdBase}-points`;
        getOrCreateSource(pointLayerId, pointFeatures);
        getOrCreateLayer(
          pointLayerId,
          'circle',
          pointLayerId,
          { 'circle-color': '#FF0000', 'circle-radius': 5 },
          visibility
        );
        layersToUpdate.points.push(pointLayerId);
      }

      if (lineStringFeatures.features.length > 0) {
        const lineLayerId = `${layerIdBase}-lines`;
        getOrCreateSource(lineLayerId, lineStringFeatures);
        getOrCreateLayer(
          lineLayerId,
          'line',
          lineLayerId,
          { 'line-color': '#0000FF', 'line-width': 2 },
          visibility
        );
        layersToUpdate.lines.push(lineLayerId);
      }

      if (polygonFeatures.features.length > 0) {
        const polygonLayerId = `${layerIdBase}-polygons`;
        const borderLayerId = `${layerIdBase}-border`;

        getOrCreateSource(polygonLayerId, polygonFeatures);
        getOrCreateLayer(
          polygonLayerId,
          'fill',
          polygonLayerId,
          { 'fill-color': '#00FF00', 'fill-opacity': 0.35 },
          visibility
        );
        layersToUpdate.polygons.push(polygonLayerId);

        getOrCreateSource(borderLayerId, polygonFeatures);
        getOrCreateLayer(
          borderLayerId,
          'line',
          borderLayerId,
          { 'line-color': '#009900', 'line-width': 2 },
          visibility
        );
        layersToUpdate.polygons.push(borderLayerId);
      }
    });

    // Popup for polygons
    const popup = new mapboxgl.Popup({ closeButton: true, closeOnClick: true, offset: [0, -10] });
    const handlePopup = (e) => {
      const feature = e.features[0];
      const coordinates = e.lngLat;
      const area = parseFloat(feature.properties.area);
      const displayArea = isNaN(area) ? "Area's information not available" : `${area.toFixed(2)} m²`;
      const popupHTML = `<div style="text-align: center;"><p><strong>Area:</strong> ${displayArea}</p></div>`;
      popup.setLngLat(coordinates).setHTML(popupHTML).addTo(map);
    };

    layersToUpdate.polygons.forEach((polygonLayerId) => {
      map.on('click', polygonLayerId, handlePopup);
    });
  }, [layers, tiffLayers, mapLoaded]);

  // Hook up update on move/zoom
  useEffect(() => {
    const map = mapRef.current;
    if (map) {
      map.on('moveend', updateMapLayers);
      map.on('zoomend', updateMapLayers);
    }
    return () => {
      if (map) {
        map.off('moveend', updateMapLayers);
        map.off('zoomend', updateMapLayers);
      }
    };
  }, [updateMapLayers]);

  // Zoom to a specific raster (TIFF) bounding box
  useEffect(() => {
    if (!Rasterzoomid || !mapLoaded) return;
    const map = mapRef.current;
    const selectedTiffLayer = tiffLayers.find((tiff) => tiff.id === Rasterzoomid);
    if (selectedTiffLayer && selectedTiffLayer.boundingBox) {
      const { boundingBox } = selectedTiffLayer;
      const bounds = [
        [parseFloat(boundingBox.minx), parseFloat(boundingBox.miny)],
        [parseFloat(boundingBox.maxx), parseFloat(boundingBox.maxy)],
      ];
      map.fitBounds(bounds, {
        padding: { top: 10, bottom: 10, left: 10, right: 10 },
        maxZoom: 15,
        duration: 1000,
      });
      setRasterzoomid(null);
    }
  }, [Rasterzoomid, tiffLayers, mapLoaded, setRasterzoomid]);

  const handleThemeChange = (newTheme) => {
    if (!mapRef.current) return;
    const map = mapRef.current;
    map.setStyle(`mapbox://styles/mapbox/${newTheme}`);
    map.once('styledata', () => {
      updateMapLayers();
    });
  };

  const handleRasterZoom = useCallback(
    (rasterId) => {
      const map = mapRef.current;
      const selectedTiff = tiffLayers.find((tiff) => tiff.id === rasterId);
      if (selectedTiff && selectedTiff.boundingBox) {
        const { minx, miny, maxx, maxy } = selectedTiff.boundingBox;
        map.fitBounds(
          [
            [parseFloat(minx), parseFloat(miny)],
            [parseFloat(maxx), parseFloat(maxy)],
          ],
          { padding: { top: 10, bottom: 10, left: 10, right: 10 }, maxZoom: 15, duration: 0 }
        );
      }
    },
    [tiffLayers]
  );

  // Re-apply layers when inputs change
  useEffect(() => {
    updateMapLayers();
  }, [updateMapLayers]);

  // Trigger zoom if Rasterzoomid set externally
  useEffect(() => {
    if (Rasterzoomid) handleRasterZoom(Rasterzoomid);
  }, [Rasterzoomid, handleRasterZoom]);

  // ---------- RENDER ----------
  return (
    <>
      {Loading ? (
        <Loader />
      ) : (
        <div className="relative w-full h-full">
          <div ref={mapContainerRef} className="map-container" />
          <ThemeSelector onThemeChange={handleThemeChange} />
        </div>
      )}
    </>
  );
};

export default MapboxMap;