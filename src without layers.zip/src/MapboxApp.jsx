import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import MapboxMap from './Mapbox';
import Sidebar from './Sidebar';
import { db } from './firebase';
import { doc, deleteDoc } from "firebase/firestore";
import './App.css';
import Header from './Header';

const MapboxApp = () => {
  const [layers, setLayers] = useState([]);
  const [tiffLayers, setTiffLayers] = useState([]);
  const [selectedLayerId, setSelectedLayerId] = useState('');
  const [zoomToLayerId, setZoomToLayerId] = useState(null);
  const [Rasterzoomid, setRasterzoomid] = useState(null);
  const [statusMessage, setStatusMessage] = useState('');
  const [activeSection, setActiveSection] = useState('geojson'); // 'geojson' | 'tiff'
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [converted, setConverted] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const location = useLocation();

  // Open Layers via URL query (e.g., /mapbox?panel=layers)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('panel') === 'layers') {
      setIsSidebarOpen(true);
      setActiveSection('geojson');
      
      // Dispatch custom event to let other components know
      window.dispatchEvent(new CustomEvent('open-layers-panel', { 
        detail: { tab: 'geojson' } 
      }));
    }
  }, [location.search]);

  // 🔔 Also open Layers when the sidebar fires a custom event
  useEffect(() => {
    const openHandler = (e) => {
      setIsSidebarOpen(true);
      setActiveSection(e?.detail?.tab || 'geojson');
    };
    window.addEventListener('open-layers-panel', openHandler);
    return () => window.removeEventListener('open-layers-panel', openHandler);
  }, []);

  const fetchPostGislayers = async () => {
    try {
      const response = await fetch("https://nodeback.duckdns.org/api/layers");
      if (!response.ok) throw new Error('Network response was not ok');
      const layersData = await response.json();
      setLayers(layersData);
    } catch (error) {
      console.error('Error fetching PostGIS layers:', error);
    }
  };

  const fetchTiffLayers = async () => {
    try {
      const response = await fetch("https://nodeback.duckdns.org/api/tiff-layers");
      if (!response.ok) throw new Error('Network response was not ok');
      const tiffLayersData = await response.json();
      setTiffLayers(tiffLayersData);
    } catch (error) {
      console.error('Error fetching TIFF layers:', error);
    }
  };

  useEffect(() => {
    fetchPostGislayers();
    fetchTiffLayers();
  }, []);

  const handleToggleLayer = (id) => {
    setLayers((prev) =>
      prev.map((layer) => (layer.id === id ? { ...layer, visible: !layer.visible } : layer))
    );
  };

  const handleGeoJsonUpload = async (geojson, name) => {
    const existingLayer = layers.find((layer) => layer.name === name);
    if (existingLayer) {
      console.error('Layer with this name already exists');
      return;
    }
    const layerId = `layer-${Date.now()}`;
    const newLayer = { id: layerId, data: geojson, name, visible: true };
    setLayers((prev) => [...prev, newLayer]);
  };

  const handleDeleteLayer = async (id) => {
    try {
      await deleteDoc(doc(db, "layers", id));
      setLayers((prev) => prev.filter((layer) => layer.id !== id));
    } catch (error) {
      console.error("Error deleting layer:", error);
    }
  };

  return (
    <>
      <Header
        isNotificationOpen={isNotificationOpen}
        progress={isUploading ? progress : 0}
        converted={converted}
        setIsNotificationOpen={setIsNotificationOpen}
        showLoader={isUploading}
        onBurgerClick={() => setIsSidebarOpen(!isSidebarOpen)}
      />
      <div className="flex flex-row-reverse h-[calc(100vh-64px)]">
        {isSidebarOpen && (
          <Sidebar
            onGeoJsonUpload={handleGeoJsonUpload}
            layers={layers}
            onToggleLayer={handleToggleLayer}
            onDeleteLayer={handleDeleteLayer}
            setSelectedLayerId={setSelectedLayerId}
            handleClickZoom={(id) => setZoomToLayerId(id)}
            tiffLayers={tiffLayers}
            setTiffLayers={setTiffLayers}
            setActiveSection={setActiveSection}
            activeSection={activeSection}   // controls GeoJSON/TIFF tab
            handleRasterZoom={setRasterzoomid}
            handleDeleteTiffLayer={() => {}}
          />
        )}
        <MapboxMap
          layers={layers}
          zoomid={zoomToLayerId}
          setZoom={setZoomToLayerId}
          Rasterzoomid={Rasterzoomid}
          setRasterzoomid={setRasterzoomid}
          tiffLayers={tiffLayers}
        />
      </div>
    </>
  );
};

export default MapboxApp;