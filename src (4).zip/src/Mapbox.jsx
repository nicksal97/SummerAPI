﻿// Mapbox.jsx (only the return statement needs updating)
// ... rest of the code remains the same

return (
  <>
    {
      Loading ?
        <Loader />
      :
      <div className="relative w-full h-full">
        <div ref={mapContainerRef} className="map-container" />
        <ThemeSelector onThemeChange={handleThemeChange} /> 
      </div>
    }
  </>
);