﻿// src/Mapbox.jsx
import { useEffect, useRef, useState, useCallback } from 'react';
import mapboxgl from 'mapbox-gl';
import './App.css';
import ThemeSelector from './ThemeSwitcher';
import { useNavigate } from 'react-router-dom';
import Loader from './components/Loader';

mapboxgl.accessToken =
  'pk.eyJ1IjoibWlya2hhZ2FuIiwiYSI6ImNtMDQzYnBtNjAycmkyanNibXRvaTg3dDIifQ.PPYVLIlidbRLbaiaHiie2g';

const MapboxMap = ({
  layers,
  zoomid,
  setZoom,
  Rasterzoomid,
  tiffLayers,
  setRasterzoomid,
}) => {
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);
  const navigate = useNavigate();
  const [mapLoaded, setMapLoaded] = useState(false);
  const [Loading, setLoading] = useState(true);

  // ---------- Login guard ----------
  useEffect(() => {
    const id = sessionStorage.getItem('mapbox_unique');
    if (!id) {
      navigate('/');
    }
    setLoading(false);
  }, [navigate]);

  // ---------- Reprojection helpers (only if clearly WebMercator) ----------
  const epsg3857toEpsg4326 = (pos) => {
    let [x, y] = pos;
    x = (x * 180) / 20037508.34;
    y = (y * 180) / 20037508.34;
    y = (Math.atan(Math.exp((y * Math.PI) / 180)) * 360) / Math.PI - 90;
    return [x, y];
  };

  const to4326IfNeeded = (coordPair) => {
    if (Math.abs(coordPair[0]) > 180 || Math.abs(coordPair[1]) > 90) {
      return epsg3857toEpsg4326(coordPair);
    }
    return coordPair;
  };

  // ---------- Coordinate collector (works for any geometry) ----------
  const collectCoords = (geometry) => {
    const out = [];
    const walk = (coords) => {
      if (!coords) return;
      // coords is a pair -> push
      if (Array.isArray(coords) && typeof coords[0] === 'number') {
        out.push(to4326IfNeeded(coords));
        return;
      }
      // coords is nested arrays
      if (Array.isArray(coords)) {
        coords.forEach(walk);
      }
    };

    if (!geometry) return out;
    // Feature geometry always has "coordinates"
    walk(geometry.coordinates);
    return out;
  };

  // Convert an entire FeatureCollection (in place is okay because we guard with to4326IfNeeded)
  const convertGeoJSON = (geojsonData) => {
    if (!geojsonData?.features) return geojsonData;
    geojsonData.features.forEach((feature) => {
      // simply touch all coords to normalize CRS (no need to reassign; collector does it lazily)
      // no-op here because we normalize during collection and when painting
      return feature;
    });
    return geojsonData;
  };

  // ---------- Map init ----------
  const initializeMap = useCallback(() => {
    if (mapRef.current || !mapContainerRef.current) return;

    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [0, 0],
      zoom: 1,
      attributionControl: false,
    });

    mapRef.current = map;

    map.on('load', () => {
      setMapLoaded(true);
      setTimeout(() => map.resize(), 300);
    });
  }, []);

  useEffect(() => {
    const t = setTimeout(initializeMap, 100);
    return () => clearTimeout(t);
  }, [initializeMap]);

  // ---------- Fit to any FeatureCollection ----------
  const fitToFeatureCollection = useCallback(
    (fc) => {
      const map = mapRef.current;
      if (!map || !fc?.features?.length) return;

      const bounds = new mapboxgl.LngLatBounds();
      let hasAny = false;

      fc.features.forEach((f) => {
        const coords = collectCoords(f.geometry);
        coords.forEach((c) => {
          bounds.extend(c);
          hasAny = true;
        });
      });

      if (hasAny && !bounds.isEmpty()) {
        map.fitBounds(bounds, { padding: 50, maxZoom: 15, duration: 300 });
      }
    },
    []
  );

  // ---------- Paint / update layers ----------
  const updateMapLayers = useCallback(() => {
    if (!mapLoaded) return;
    const map = mapRef.current;
    if (!map) return;

    // ===== Raster (TIFF via tiles) =====
    tiffLayers.forEach((tiff) => {
      const { id, boundingBox, mapboxUrl } = tiff;
      if (!boundingBox || !mapboxUrl) return;

      const sourceId = `raster-layer-${id}`;
      if (!map.getSource(sourceId)) {
        map.addSource(sourceId, { type: 'raster', tiles: [mapboxUrl], tileSize: 512 });
      }
      if (!map.getLayer(sourceId)) {
        map.addLayer({ id: sourceId, type: 'raster', source: sourceId, layout: { visibility: 'visible' } });
      }
    });

    // ===== Vector GeoJSON =====
    layers.forEach((layer) => {
      const base = `geojson-layer-${layer.id}`;
      const data = convertGeoJSON(layer.data);

      // Build three filtered FCs
      const points = {
        type: 'FeatureCollection',
        features: data?.features?.filter((f) => f.geometry?.type === 'Point') ?? [],
      };
      const lines = {
        type: 'FeatureCollection',
        features:
          data?.features?.filter((f) =>
            ['LineString', 'MultiLineString'].includes(f.geometry?.type)
          ) ?? [],
      };
      const polys = {
        type: 'FeatureCollection',
        features:
          data?.features?.filter((f) =>
            ['Polygon', 'MultiPolygon'].includes(f.geometry?.type)
          ) ?? [],
      };

      const visible = layer.visible ? 'visible' : 'none';

      const ensureSource = (id, fc) => {
        if (!map.getSource(id)) map.addSource(id, { type: 'geojson', data: fc });
        else map.getSource(id).setData(fc);
      };
      const ensureLayer = (id, type, src, paint) => {
        if (!map.getLayer(id)) map.addLayer({ id, type, source: src, paint, layout: { visibility: visible } });
        else {
          map.setLayoutProperty(id, 'visibility', visible);
          Object.entries(paint).forEach(([k, v]) => map.setPaintProperty(id, k, v));
        }
      };

      if (points.features.length) {
        const id = `${base}-points`;
        ensureSource(id, points);
        ensureLayer(id, 'circle', id, { 'circle-color': '#FF4D4D', 'circle-radius': 5 });
      }
      if (lines.features.length) {
        const id = `${base}-lines`;
        ensureSource(id, lines);
        ensureLayer(id, 'line', id, { 'line-color': '#2563eb', 'line-width': 2 });
      }
      if (polys.features.length) {
        const fillId = `${base}-polygons`;
        const borderId = `${base}-border`;
        ensureSource(fillId, polys);
        ensureLayer(fillId, 'fill', fillId, { 'fill-color': '#22c55e', 'fill-opacity': 0.35 });
        ensureSource(borderId, polys);
        ensureLayer(borderId, 'line', borderId, { 'line-color': '#16a34a', 'line-width': 2 });

        // polygon popup
        const clickHandler = (e) => {
          const feature = e.features?.[0];
          if (!feature) return;
          const area = parseFloat(feature.properties?.area);
          const displayArea = isNaN(area) ? "Area's information not available" : `${area.toFixed(2)} m²`;
          new mapboxgl.Popup({ closeButton: true, closeOnClick: true, offset: [0, -10] })
            .setLngLat(e.lngLat)
            .setHTML(`<div style="text-align:center;"><strong>Area:</strong> ${displayArea}</div>`)
            .addTo(map);
        };
        // avoid duplicate listeners
        map.off('click', fillId, clickHandler);
        map.on('click', fillId, clickHandler);
      }
    });
  }, [layers, tiffLayers, mapLoaded]);

  // Update layers whenever inputs change
  useEffect(() => {
    updateMapLayers();
  }, [updateMapLayers]);

  // ---------- Zoom to a selected GeoJSON layer ----------
  useEffect(() => {
    if (!mapLoaded || !zoomid) return;
    const selected = layers.find((l) => l.id === zoomid);
    if (selected?.data) fitToFeatureCollection(selected.data);
    // reset trigger
    setZoom?.(null);
  }, [zoomid, mapLoaded, layers, fitToFeatureCollection, setZoom]);

  // ---------- Zoom to a selected TIFF layer ----------
  useEffect(() => {
    if (!Rasterzoomid || !mapLoaded) return;
    const map = mapRef.current;
    const selectedTiff = tiffLayers.find((t) => t.id === Rasterzoomid);
    if (selectedTiff?.boundingBox) {
      const { minx, miny, maxx, maxy } = selectedTiff.boundingBox;
      map.fitBounds([[+minx, +miny], [+maxx, +maxy]], {
        padding: { top: 10, bottom: 10, left: 10, right: 10 },
        maxZoom: 15,
        duration: 300,
      });
    }
    setRasterzoomid?.(null);
  }, [Rasterzoomid, tiffLayers, mapLoaded, setRasterzoomid]);

  // ---------- Theme switch ----------
  const handleThemeChange = (newTheme) => {
    const map = mapRef.current;
    if (!map) return;
    map.setStyle(`mapbox://styles/mapbox/${newTheme}`);
    // when style reloads, sources/layers are cleared → repaint
    map.once('styledata', () => updateMapLayers());
  };

  // ---------- Render ----------
  return (
    <>
      {Loading ? (
        <Loader />
      ) : (
        <div className="relative w-full h-full">
          <div ref={mapContainerRef} className="map-container" />
          <ThemeSelector onThemeChange={handleThemeChange} />
        </div>
      )}
    </>
  );
};

export default MapboxMap;