﻿import React, { useEffect, useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import Loader from "./components/Loader";
import { useNavigate } from 'react-router-dom';
import { BASE_URL } from "./utils/constants";


const UploadModelPage = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState("winter");
  const [file, setFile] = useState(null);
  const [summerFiles, setSummerFiles] = useState([]); 
  const [winterFiles, setWinterFiles] = useState([]);
  const [Loading, setLoading] = useState(true);

  useEffect(() => {
    const id = sessionStorage.getItem('mapbox_unique');
    if(!id) {
      navigate('/');
      setLoading(false)
    } else {
      setLoading(false)
    }
  }, [])

  // Handle file input change
  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  // Handle model type selection change
  const handleModelChange = (e) => {
    setSelectedModel(e.target.value);
    fetchModelNames(e.target.value)
  };

  useEffect(() => {
    const fetchModelData = async () => {

      axios
      .get(`${BASE_URL}/model-upload/?model=winter`)
      .then((res) => {
        if (res.status === 200) {
          setSummerFiles(res?.data?.summer_path);
          setWinterFiles(res?.data?.winter_path);
        }
      })
      .catch((err) => {
        // console.log("Error:", err);
      });
    };
    fetchModelData();
  }, [])

  const fetchModelNames = async (model) => {
    axios.get(`${BASE_URL}/model-upload/?model=${model}`)
      .then((res) => {
        if (res.status === 200) {
          setSummerFiles(res?.data?.summer_path);
          setWinterFiles(res?.data?.winter_path);
        }
      })
      .catch((err) => {
        // console.log("Error:", err);
      });
  };

  // Function to fetch model names
  

  // Handle form submission
  const handleSubmit = async () => {
    console.log("Submit button clicked"); // Debugging
    if (!file) {
      alert("Please select the model path");
      return;
    }

    const formData = new FormData();
    formData.append("model_path", file);
    formData.append("model", selectedModel);

    setIsLoading(true);

    try {
      console.log("Making API call to /model-upload/"); // Debugging
      const response = await axios.post(`${BASE_URL}/model-upload/`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      console.log("API response:", response.data); // Debugging
      if (response.data.status) {
        alert("Model Uploaded Successfully");
        fetchModelNames(selectedModel);
      } else {
        alert("Please send a valid model path");
      }
    } catch (error) {
      console.error("Error uploading model:", error);
      alert("An error occurred while uploading the model.");
    } finally {
      setIsLoading(false);
    }
  };

  // Handle file deletion
  const handleDeleteFile = async (filename, type) => {
    console.log(`Delete button clicked for ${filename} (${type})`); // Debugging
    if (window.confirm(`Are you sure you want to delete ${filename}?`)) {
      try {
        console.log("Making API call to /delete-file/"); // Debugging
        const response = await axios.postForm(`${BASE_URL}/delete-file/`, {
          filename,
          type,
        });

        console.log("API response:", response.data); // Debugging
        if (response.data.success) {
          alert(`${filename} deleted successfully.`);
          // Refresh the file list
          if (type === "summer") {
            setSummerFiles((prev) => prev.filter((file) => file !== filename));
          } else {
            setWinterFiles((prev) => prev.filter((file) => file !== filename));
          }
        } else {
          alert(`Error deleting file: ${response.data.error}`);
        }
      } catch (error) {
        console.error("Error deleting file:", error);
        alert("An error occurred. Please try again.");
      }
    }
  };

  return (
    <>
      {
        Loading ?
        <Loader /> : 
        <div className="py-12">
          {/* Overlay for loading */}
          {isLoading && (
            <Loader />
          )}

          {/* Main container */}
          <div className="container">
            <form>
              <br />
              <br />
            <div className="flex flex-col gap-8 max-w-xl mx-auto">
                <div className="form-group w-full">
                  <label htmlFor="model" className="text-left w-full text-[16px]">Select Model Type:</label>
                  <select
                    className="form-control"
                    id="model"
                    value={selectedModel}
                    onChange={handleModelChange}
                  >
                    <option value="winter">Winter</option>
                    <option value="summer">Summer</option>
                  </select>
                </div>
                <div className="form-group w-full">
                  <label className="text-left text-[16px] w-full">Select Model Path:</label>
                  <input
                    type="file"
                    className="form-control"
                    id="model_path"
                    onChange={handleFileChange}
                  />
                </div>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleSubmit}
                >
                  Submit
                </button>
            </div>
              
            </form>
            <br />
            <br />

            {/* Display list of files for Summer */}
            <div className="flex flex-col sm:flex-row gap-8 w-full">
              <div className="flex flex-col gap-1 w-1/2">
                <h3 className="text-[18px] text-left">Files in Summer Models Directory</h3>
                <ul id="summer-file-list" className="list-group">
                  {summerFiles.length > 0 ? (
                    summerFiles.map((item, index) => (
                      <li
                        key={index}
                        className="list-group-item d-flex justify-content-between align-items-center"
                      >
                        {item}
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleDeleteFile(item, "summer")}
                        >
                          Delete
                        </button>
                      </li>
                    ))
                  ) : (
                    <li className="list-group-item">No files found</li>
                  )}
                </ul>
              </div>

              {/* Display list of files for Winter */}
              <div className="flex flex-col gap-1 w-1/2">
                <h3 className="text-[18px] text-left">Files in Winter Models Directory</h3>
                <ul id="winter-file-list" className="list-group">
                  {winterFiles.length > 0 ? (
                    winterFiles.map((item, index) => (
                      <li
                        key={index}
                        className="list-group-item d-flex justify-content-between align-items-center"
                      >
                        {item}
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleDeleteFile(item, "winter")}
                        >
                          Delete
                        </button>
                      </li>
                    ))
                  ) : (
                    <li className="list-group-item">No files found</li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        </div>
      }
    </>
  );
};

export default UploadModelPage;